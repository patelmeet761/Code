
import java.util.*;
import java.io.*;
import java.sql.*;

// Java extension packages
import javax.swing.*;

public class InsertionExample
{
    public static void main (String args[])
    {
       try {
         
         // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(
                 "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_InventoryExample/Inventory.accdb");
      
         
         Statement stmt = con.createStatement();

         stmt.execute("DROP TABLE Grades");
         
         stmt.executeUpdate("CREATE TABLE Grades" + 
                         "(StudentId int, Name varchar(20), " +
                         "Grade int)");   
                         
         int insCount = stmt.executeUpdate("INSERT INTO Grades (StudentId,Name,Grade) " + "VALUES (1,'Mickey',93)");
         insCount = stmt.executeUpdate("INSERT INTO Grades (StudentId,Name,Grade) " + "VALUES (2,'Minnie',92)");
         insCount = stmt.executeUpdate("INSERT INTO Grades (StudentId,Name,Grade) " + "VALUES (3,'Donald',89)");
            
         ResultSet rs = stmt.executeQuery("SELECT * FROM Grades ORDER BY Name");

         ResultSetMetaData rsmd = rs.getMetaData();

         int numberOfColumns = rsmd.getColumnCount();
         int rowCount = 1;
            
         System.out.println("ID Name Grade");
            
         while (rs.next())
         {
             for (int i = 1; i <= numberOfColumns; i++)
             {
                 System.out.print(rs.getString(i) + " ");
             }
             System.out.println("");
             rowCount++;
         }

         stmt.close();


       
         con.close();
            
   
      }  // end try
      
      // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }
       
   }
}