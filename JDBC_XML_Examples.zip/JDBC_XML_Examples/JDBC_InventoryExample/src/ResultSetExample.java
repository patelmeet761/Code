import java.sql.*;
import java.io.*;
import java.util.*;

// Java extension packages
import javax.swing.*;

public class ResultSetExample
{
    public static void main (String args[])
    {

         try
        {
         // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(
                 "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_InventoryExample/Inventory.accdb");
      
         
          Statement stmt = con.createStatement();

          ResultSet rs = stmt.executeQuery("SELECT * from Inventory ORDER BY ProductName");

          while (rs.next())
          {
              String product = rs.getString("ProductName");
              String description = rs.getString("ProductDescription");

              float price = rs.getFloat("Price");

              System.out.println(product + " described by many as \"" + description +
                        "\" is sold for $" + price);
          }

          stmt.close();

          con.close();

       }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }      
        

   }
}


