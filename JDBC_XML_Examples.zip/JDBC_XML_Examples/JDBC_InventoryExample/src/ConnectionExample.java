import java.util.*;
import java.io.*;
import java.sql.*;

// Java extension packages
import javax.swing.*;

public class ConnectionExample
{
    public static void main (String args[])
    {
       try {
         
         // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(
                 "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_InventoryExample/Inventory.accdb");
      
        
         
         JOptionPane.showMessageDialog(null, "Connected to Database", "CONNECTION", JOptionPane.INFORMATION_MESSAGE);
       
         con.close();
            
   
      }  // end try
      
      // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }
       
   }
}


