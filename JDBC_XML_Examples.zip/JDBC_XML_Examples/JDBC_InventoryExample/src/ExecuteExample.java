import java.util.*;
import java.io.*;
import java.sql.*;

// Java extension packages
import javax.swing.*;

public class ExecuteExample  
{
    public static void main (String args[]) throws IOException  // Added exception
    {
          
        try
        {
        // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(
                 "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_InventoryExample/Inventory.accdb");
      
         
         Statement stmt = con.createStatement();

         stmt.execute("DROP TABLE SalesHistory");
         
         stmt.execute("CREATE TABLE SalesHistory" + 
                         "(ProductID int," +
                         " Price int, " + 
                         "TrnsDate varchar(255))");
        
         System.out.println("Created Sales History table");


         stmt.close();

         con.close();
        }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }
    }
}

