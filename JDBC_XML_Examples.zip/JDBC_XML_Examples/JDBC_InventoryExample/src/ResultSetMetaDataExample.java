import java.sql.*;
import java.io.*;
import java.util.*;

// Java extension packages
import javax.swing.*;


public class ResultSetMetaDataExample
{
    public static void main (String args[])
    {
        
         try
        {
       // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(
                 "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_InventoryExample/Inventory.accdb");
      
         
          Statement stmt = con.createStatement();

          boolean notDone = true;
          String sqlStr = null;
          BufferedReader br =
                    new BufferedReader(new InputStreamReader(System.in));
          
          while (notDone)
          {
              System.out.println("Enter SELECT Statement:");
              sqlStr = br.readLine();

              if (sqlStr.startsWith("SELECT") || sqlStr.startsWith("select"))
              {
                  ResultSet rs = stmt.executeQuery(sqlStr);
                  ResultSetMetaData rsmd = rs.getMetaData();
                  int columnCount = rsmd.getColumnCount();

                  for (int x = 1; x <= columnCount; x++)
                  {
                      String columnName = rsmd.getColumnName(x);
                      System.out.print(columnName + "\t");
                  }
                  System.out.println("");

                  while (rs.next())
                  {
                      for (int x = 1; x <= columnCount; x++)
                      {
                          String resultStr = rs.getString(x);
                          System.out.print(resultStr + "\t");
                      }
                      System.out.println("");
                  }
              }
              else if (sqlStr.startsWith("exit")||sqlStr.startsWith("quit"))
                  notDone = false;
          }

          stmt.close();

          con.close();

       }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }      
         
      // detect problems with I/O
      catch ( IOException i ) {
         JOptionPane.showMessageDialog( null, 
            i.getMessage(), "IOException",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }      

   }
}


