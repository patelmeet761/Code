import java.sql.*;
import java.io.*;
import java.util.*;

// Java extension packages
import javax.swing.*;

public class SimpleJDBCExample
{
    public static void main (String args[])     {
                   
    try
        {
        // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(
                 "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_InventoryExample/Inventory.accdb");
      
         
          Statement stmt = con.createStatement();

          ResultSet rs = stmt.executeQuery("SELECT * FROM Inventory ORDER BY price");

          ResultSetMetaData rsmd = rs.getMetaData();

          int numberOfColumns = rsmd.getColumnCount();
          int rowCount = 1;

          while (rs.next())
          {
                            
              for (int i = 1; i <= numberOfColumns; i++)
              {
                  System.out.print(rs.getString(i) + " ");
              }
              System.out.println("");
              rowCount++;
          }

          rs.close();
            
          stmt.close();

          con.close();

       }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }      

   }
}


