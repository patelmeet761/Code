
import java.util.*;
import java.io.*;
import java.sql.*;

// Java extension packages
import javax.swing.*;

public class BuildAddressBookDatabase  
{
   
    public static void main (String args[]) throws IOException  // Added exception
    {
          String myConnectionLink = 
      "jdbc:ucanaccess://C:/My_Documents/Spring2019/IST242/JDBC_XML_Examples/JDBC_AddressBook/AddressBook.accdb";

        try
        {
            // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection connection = DriverManager.getConnection(myConnectionLink);
         
      
           
         Statement stmt = connection.createStatement();

        
         stmt.execute("DROP table addresses");
         stmt.execute("DROP table phoneNumbers");
         stmt.execute("DROP table emailAddresses");
         stmt.execute("DROP table names");
     
      
         System.out.println("Dropped tables");

         stmt.execute("CREATE TABLE names(" + 
                 "personID int," +
   	         "firstName varchar(30)," +
                 "lastName varchar(30))");
              
        
         System.out.println("Created names table");


         stmt.execute("CREATE TABLE addresses" + 
                 "(addressID int," + 
                 "personID int," +
	         "address1 varchar(50)," +
	         "address2 varchar(50),"+
	         "city varchar(30),"+
	         "state varchar(2)," +
	         "zipcode varchar(10))");
                 
         System.out.println("Created addresses table");
      
         stmt.execute("CREATE TABLE phoneNumbers(" + 
                "phoneID int," +
                "personID int," +
	        "phoneNumber varchar(20))");


      
         System.out.println("Created phoneNumbers table");
      
         stmt.execute("CREATE TABLE emailAddresses(" + 
                "emailID int," +
                "personID int," + 
   	        "emailAddress varchar(50))");

      
         System.out.println("Created emailAddresses table");
      
         stmt.close();

        connection.close();
     }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }
    }
}

